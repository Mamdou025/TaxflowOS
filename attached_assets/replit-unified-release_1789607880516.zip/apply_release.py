import pathlib,zipfile,json,subprocess,tempfile,shutil,sys
root=pathlib.Path.cwd().resolve()
with zipfile.ZipFile(sys.argv[1]) as archive:
 manifest=json.loads(archive.read('manifest.json'))
 staging=pathlib.Path(tempfile.mkdtemp(prefix='taxflow-release-'))
 pending=[]
 for item in manifest:
  name=item['path']; target=(root/name).resolve()
  if not target.is_relative_to(root): raise SystemExit('Invalid release path')
  incoming=archive.read('current/'+name)
  current=target.read_bytes() if target.exists() else None
  if current==incoming: continue
  if not item['base']:
   if current is not None: raise SystemExit('Existing new-file conflict: '+name)
   merged=incoming
  elif current is None: raise SystemExit('Missing existing file: '+name)
  else:
   base=archive.read('base/'+name)
   if current==base: merged=incoming
   else:
    for label,data in [('remote',current),('base',base),('incoming',incoming)]: (staging/label).write_bytes(data)
    result=subprocess.run(['git','merge-file','-p',str(staging/'remote'),str(staging/'base'),str(staging/'incoming')],capture_output=True)
    if result.returncode: raise SystemExit('Merge conflict: '+name+'; no release files written')
    merged=result.stdout
  pending.append((name,target,current,merged))
 for name,target,current,merged in pending:
  if current is not None:
   backup=staging/'backup'/name; backup.parent.mkdir(parents=True,exist_ok=True); backup.write_bytes(current)
  target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(merged)
  print('Updated '+name)
 print('Release files updated:',len(pending)); print('Backup:',staging/'backup')
